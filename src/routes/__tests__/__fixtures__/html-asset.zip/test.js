var x = "test js code"
