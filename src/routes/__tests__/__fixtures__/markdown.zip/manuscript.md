
A Test Manuscript
=================



Alf Eaton^^

# 1. A paragraph {#MPSection:A67FABCE-B7A0-457A-95C0-3A6B4AFD80BB}

This is a paragraph with **bold**, *italic*, underlined, ~subscript~ and ^superscript^ text.

# 2. A citation {#MPSection:62247D30-86C2-40C8-9B25-55E323397F57}

This paragraph contains a citation\[Introducing Manuscripts.io: open source editing environment for structured, computationally reproducible research documents\](\#Piipari2019);;.

# 3. An equation {#MPSection:D015E1FF-1880-48EC-B8A3-4C9CD37E3B2D}

This paragraph contains an inline equation: 2+3=5

<div id="MPEquationElement:4311CDC7-70FF-48A3-9C63-176210C962D4">

x + y = z

</div>

# 4. An ordered list {#MPSection:7EB59268-1C3A-4522-B250-A7B09AC5C97D}

1.  An ordered list
2.  With two items
    1.  A nested item

# 5. A bullet list {#MPSection:6AFAA84A-3E7D-40B8-96F0-72EFB0DD2165}

-   A bullet list
-   With two items
    -   A nested item

# 6. A table {#MPSection:E03BA80F-AAF5-4050-961E-380DF6993D0C}

This is a table

| Test | Test |
|------|------|
| Test | Test |
| Test | Test |
| Test | Test |

: **Table 1:** An example table

# 7. A figure {#MPSection:3A1ECA84-AA87-4E3A-AB70-6686FF6FE452}

This is a figure

<div id="MPFigureElement:A7BBA561-7FA2-4576-981B-3D75E91B614A">

![](Figure_1.png)

Figure 1: The Manuscripts logo

</div>

# 8. Bibliography {#MPSection:FFC7095E-A048-4CC4-BFF3-ADA4AF2C919E}

<div id="MPBibliographyElement:C65083EA-1727-4AC4-900B-B89FA4376CFB" xmlns="http://www.w3.org/1999/xhtml">

1.

Piipari, M., Eaton, A. & Pepe, A. [*Introducing Manuscripts.io: open source editing environment for structured, computationally reproducible research documents*](https://www.ncbi.nlm.nih.gov/books/NBK540955/). (National Center for Biotechnology Information (US), 2019).

</div>
